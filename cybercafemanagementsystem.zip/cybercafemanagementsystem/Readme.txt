How to run the Cyber Cafe Management System (CCMS) Project

1. Download the zip file

2. Extract the file and copy ccms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name ccmsdb

6. Import ccmsdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/ccms(frontend)

Credential for admin panel :

Username: admin
Password: Test@123

